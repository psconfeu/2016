 <# http://git.io/b3oo #>

# install the module (PS v3 and SMO required)
Invoke-Expression (Invoke-WebRequest -UseBasicParsing  http://git.io/vn1hQ).Content

# Test Connection - I'll need this if you have issues.
Test-SqlConnection oldsql

# Change the max memory real quick
Get-SqlMaxMemory -SqlServers oldsql, newsql
Get-SqlMaxMemory -SqlServers oldsql, newsql | Where-Object {$_.SqlMaxMB -gt $_. TotalMB } | Set-SqlMaxMemory -UseRecommended

# Create new login called migrateme, then migrate. 
Copy-SqlLogin -Source oldsql -Destination newsql -Logins migrateme -force

#  Single database Detach/attach
Copy-SqlDatabase -source oldsql -Destination newsql -Detach -Reattach -Database sharepoint_webanalytics_reporting

# Pipe SQLPS' Get-Database to an Out-GridView to select just a few databases
# See example video here: https://twitter.com/cl/status/722152905340502017

Import-Module SQLPS
Get-SqlDatabase -ServerInstance oldsql | Out-GridView -PassThru | Copy-SqlDatabase -Destination newsql -BackupRestore –NetworkShare \\nas\share\Migration

#  Detach/attach migration with a -whatif
Start-SqlMigration -Source oldsql -Destination newsql -Detach -Reattach -Whatif

# Actually do it.
Start-SqlMigration -Source oldsql -Destination newsql -BackupRestore -NetworkShare \\nas\share\Migration

# Restore Hallengren Backups    
Restore-HallengrenBackup -SqlServer newsql -Path \\nas\share\SQLBACKUPS\staging -NoRecovery -Force

# look at transcript
notepad .\dbatools-startmigration-transcript.txt