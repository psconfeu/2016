﻿Describe 'Testing services' {
    
    It 'W32Time is running' {
        (Get-Service -Name W32Time).Status | Should be 'Running'
    }
    
    It 'Start-Demo is defined in AllUserAllHost profile' {
        $Profile.AllUsersAllHosts | Should Contain 'Function Start-Demo'
    }
    
    It 'All profile scripts contains comment "#This is a profile"' {
        $Profile.psobject.Properties.Value.Where{Test-Path $_} | Should Contain '#This is a profile'
    }

}