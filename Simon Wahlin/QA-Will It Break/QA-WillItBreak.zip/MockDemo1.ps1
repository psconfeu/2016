﻿Function Test-One ($Path) {
    Get-Content $Path
}


Describe 'DemoTest' {
    Context 'MockDemo' {
        
        Mock Get-Content {Write-Output 'File content'} –ParameterFilter {$Path –eq 'C:\Logs\Log.log'} -Verifiable
        
        It 'Returns content of file' {
            test-one -Path 'C:\Logs\Log.log' | 
                Should be 'File content'
        }
        
        It 'Runs Get-Content Mock once' {
            Assert-MockCalled Get-Content -Exactly -Times 1
        }
        
        It 'Runs all verifiable Mocks' {
            if('diföaos' -ne $A){throw 'Not as expected'}
            Assert-VerifiableMocks
        }
    
    }
}

