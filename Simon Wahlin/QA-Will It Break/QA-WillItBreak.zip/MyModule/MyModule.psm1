﻿Function test-two {
    [cmdletbinding()]
    Param($Path)
    Write-PVerbose -Message $Path
    Get-Content -Path $Path
}

Function Write-PVerbose {
    [cmdletbinding()]
    Param(
        $Message
    )
    Write-Verbose -Message $Message
}

Export-ModuleMember -Function test-two