﻿Remove-Module MyModule -Force -ErrorAction SilentlyContinue
Import-Module $PSScriptRoot\MyModule -Force -ErrorAction Stop

Describe 'DemoTest' {
    
    Context 'MockDemo' {

        # Mock declared within module
        Mock Get-Content {'File content'} –ParameterFilter {$Path –eq 'C:\Logs\Log.log'} -Verifiable -ModuleName MyModule
        
        It 'Returns content of file' {
            
            test-two -Path 'C:\Logs\Log.log' | 
                Should be 'File content'
        }
        
        It 'Runs Get-Content Mock once' {
            # Assert mock within module
            Assert-MockCalled Get-Content -Exactly -Times 1 -ModuleName MyModule
        }
        
        It 'Runs all verifiable Mocks' {
            Assert-VerifiableMocks
        }
    }
    
    Context 'InModuleScope' {
        
        InModuleScope -ModuleName MyModule {
           
            Mock Write-Verbose {Write-Output $Message}
            
            It 'Writes path to verbose stream' {
                Write-PVerbose -Message 'Mypath' |
                    Should be 'Mypath'
            }

        }

    }
    
}
