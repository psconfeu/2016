﻿[DSCLocalConfigurationManager()]
configuration PartialConfigInMixed
{
    param (
        [Parameter(Mandatory)]
        [String] $PullServerUrl,

        [Parameter(Mandatory)]
        [String] $RegistrationKey,

        [Parameter()]
        [String] $NodeName = 'localhost'
    )

    Node $NodeName
    {
        Settings
        {
            RefreshMode = 'Pull'
            RefreshFrequencyMins = 30 
            RebootNodeIfNeeded = $true
        }

        ConfigurationRepositoryWeb PullServer
        {
            ServerURL = $PullServerUrl
            RegistrationKey = $RegistrationKey
            ConfigurationNames = @('TestService')
            AllowUnsecureConnection = $true
        }   

        ReportServerWeb ReportServer
        {
            ServerURL         = $PullServerUrl
            RegistrationKey   = $RegistrationKey
            AllowUnsecureConnection = $true
        }

        PartialConfiguration TestService
        {
            Description = 'Test Audio Service'
            ConfigurationSource = '[ConfigurationRepositoryWeb]PullServer'
            RefreshMode = 'Pull'
        }

        PartialConfiguration TestDependentService
        {
            Description = 'Test Dependent Service'
            RefreshMode = 'Push'
            DependsOn = '[PartialConfiguration]TestService'
        }
    }
}

PartialConfigInMixed -NodeName PSConfEu-VM3 -PullServerUrl 'http://psconfeu-dc:8080/PSDSCPullServer.svc' -RegistrationKey '6d271d28-dd50-4b16-86d3-b917d2d7b1af' -OutputPath C:\Demos\PartialConfigInMixed -Verbose
Set-DscLocalConfigurationManager -Path C:\Demos\PartialConfigInMixed -Verbose

#Publish the push fragment
Publish-DscConfiguration -Path C:\Demos\PCandCNS\Configurations\TestDependentService -ComputerName PSConfEU-VM3 -Verbose

#Update DSC configuration for second fragment to get pulled
Update-DscConfiguration -ComputerName PSConfEU-VM3 -Wait -Verbose