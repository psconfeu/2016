﻿[DSCLocalConfigurationManager()]
configuration PartialConfigInPullWithConfigurationID
{
    param (
        [Parameter(Mandatory)]
        [String] $PullServerUrl,

        [Parameter()]
        [String] $NodeName = 'localhost'
    )

    Node $NodeName
    {
        Settings
        {
            ConfigurationID = '2da6bb22-f051-479c-ba59-b54a18d6eb38'
            RefreshMode = 'Pull'
            RefreshFrequencyMins = 30 
            RebootNodeIfNeeded = $true
        }

        ConfigurationRepositoryWeb PullServer
        {
            ServerURL = $PullServerUrl
            AllowUnsecureConnection = $true
        }   

        ReportServerWeb ReportServer
        {
            ServerURL         = $PullServerUrl
            AllowUnsecureConnection = $true
        }

        PartialConfiguration TestService
        {
            Description = 'Test Audio Service'
            ConfigurationSource = '[ConfigurationRepositoryWeb]PullServer'
            RefreshMode = 'Pull'
        }

        PartialConfiguration TestDependentService
        {
            Description = 'Test Dependent Service'
            ConfigurationSource = '[ConfigurationRepositoryWeb]PullServer'
            RefreshMode = 'Pull'
            DependsOn = '[PartialConfiguration]TestService'
        }
    }
}

PartialConfigInPullWithConfigurationID -NodeName PSConfEu-VM5 -PullServerUrl 'http://psconfeu-dc:8080/PSDSCPullServer.svc' -OutputPath C:\Demos\PartialConfigInPullWithConfigurationID -Verbose
Set-DscLocalConfigurationManager -Path C:\Demos\PartialConfigInPullWithConfigurationID -Verbose

#Start enact
Update-DscConfiguration -ComputerName PSConfEu-VM5 -Wait -Verbose

#Get DSC Configuartion
Get-DSCConfiguration -CimSession PSConfEU-VM1 -Verbose