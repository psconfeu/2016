﻿[DSCLocalConfigurationManager()]
configuration PartialConfigInPull
{
    param (
        [Parameter(Mandatory)]
        [String] $PullServerUrl,

        [Parameter(Mandatory)]
        [String] $RegistrationKey,

        [Parameter()]
        [String] $NodeName = 'localhost'
    )

    Node $NodeName
    {
        Settings
        {
            RefreshMode = 'Pull'
            RefreshFrequencyMins = 30 
            RebootNodeIfNeeded = $true
        }

        ConfigurationRepositoryWeb PullServer
        {
            ServerURL = $PullServerUrl
            RegistrationKey = $RegistrationKey
            ConfigurationNames = @('TestService','TestDependentService')
            AllowUnsecureConnection = $true
        }   

        ReportServerWeb ReportServer
        {
            ServerURL         = $PullServerUrl
            RegistrationKey   = $RegistrationKey
            AllowUnsecureConnection = $true
        }

        PartialConfiguration TestService
        {
            Description = 'Test Audio Service'
            ConfigurationSource = '[ConfigurationRepositoryWeb]PullServer'
            RefreshMode = 'Pull'
        }

        PartialConfiguration TestDependentService
        {
            Description = 'Test Dependent Service'
            ConfigurationSource = '[ConfigurationRepositoryWeb]PullServer'
            RefreshMode = 'Pull'
            DependsOn = '[PartialConfiguration]TestService'
        }
    }
}

PartialConfigInPull -NodeName PSConfEu-VM1 -PullServerUrl 'http://psconfeu-dc:8080/PSDSCPullServer.svc' -RegistrationKey '6d271d28-dd50-4b16-86d3-b917d2d7b1af' -OutputPath C:\Demos\PartialConfigInPull -Verbose
Set-DscLocalConfigurationManager -Path C:\Demos\PartialConfigInPull -Verbose

#Start enact
Update-DscConfiguration -ComputerName PSConfEu-VM1 -Wait -Verbose

#Get DSC Configuartion
Get-DSCConfiguration -CimSession PSConfEU-VM1 -Verbose