﻿$buf = [Text.Encoding]::Unicode.GetBytes('[Service]TestAudioService')
$data = [System.Convert]::ToBase64String($buf)

Invoke-WSManAction -ResourceURI http://schemas.microsoft.com/wbem/wsman/1/wmi/root/microsoft/windows/DesiredStateConfigurationProxy/MSFT_DscProxy `
                    -action GetResourceState -ComputerName psconfeu-vm1 -valueset @{ConfigurationData = "$data" } `
                    -Authentication None