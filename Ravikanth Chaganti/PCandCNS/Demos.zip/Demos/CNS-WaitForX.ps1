﻿Configuration CNSDemo {
    Node PSConfEU-VM6 {
        Service TestAudioService {
            Name = 'AudioSrv'
            State = 'Running'
            DependsOn = '[WaitForAll]OtherNodes'
        }

        WaitForAll OtherNodes {
            NodeName = 'PSConfEU-VM1','PSConfEU-VM2'
            ResourceName = '[Service]TestAudioService'
            RetryIntervalSec = 5
            RetryCount = 30
        }
    }
}

CNSDemo -OutputPath C:\Demos\CNSDemo -Verbose
Start-DscConfiguration -Verbose -Wait -Path C:\Demos\CNSDemo -Force