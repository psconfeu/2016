﻿#Get LCM Settings
Get-DscLocalConfigurationManager -CimSession PSConfEU-VM5

#Get PartialConfiguration Meta settings
Get-CimClass -ClassName MSFT_PartialConfiguration -Namespace root/Microsoft/Windows/DesiredStateConfiguration
#Output
#Name                 Qualifiers
#----                 ----------
#ResourceId           {Required}
#SourceInfo           {write}   
#ConfigurationSource  {write}   
#DependsOn            {write}   
#Description          {write}   
#ExclusiveResources   {write}   
#RefreshMode          {ValueMap}
#ResourceModuleSource {write} 

#LCM Configuration for Partial Configurations with ConfigurationID
psEdit C:\Demos\PCandCNS\Partial-PullMode_ConfigurationID.ps1

#LCM configuration for Partial configuraiton pull
psEdit C:\Demos\PCandCNS\Partial-PullMode.ps1

#LCM Configuraiton for partial configuration in push
psEdit C:\Demos\PCandCNS\Partial-PushMode.ps1

#LCM Configuration for partial configuration in mixed mode
psEdit C:\Demos\PCandCNS\Partial-MixedMode.ps1

#LCM Configuration for partial configurations with exclusive resources
psEdit C:\Demos\PCandCNS\Partial-ExclusiveResources.ps1

#Get WaitFor resources
Get-DscResource -Name WaitForAny -Syntax
Get-DscResource -Name WaitForSome -Syntax
Get-DscResource -Name WaitForAll -Syntax

#CNS core
psEdit C:\Demos\PCandCNS\CNS-Core.ps1

#CNS WaitFor Resources
psEdit C:\Demos\PCandCNS\CNS-WaitForX.ps1