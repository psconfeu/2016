﻿[DSCLocalConfigurationManager()]
configuration PartialConfigInPush
{
    param (
        [Parameter(Mandatory)]
        [String] $PullServerUrl,

        [Parameter(Mandatory)]
        [String] $RegistrationKey,

        [Parameter()]
        [String] $NodeName = 'localhost'
    )

    Node $NodeName
    {
        Settings
        {
            RefreshMode = 'Push'
            RefreshFrequencyMins = 30 
            RebootNodeIfNeeded = $true
        } 

        ReportServerWeb ReportServer
        {
            ServerURL         = $PullServerUrl
            RegistrationKey   = $RegistrationKey
            AllowUnsecureConnection = $true
        }

        PartialConfiguration TestService
        {
            Description = 'Test Audio Service'
            RefreshMode = 'Push'
        }

        PartialConfiguration TestDependentService
        {
            Description = 'Test Dependent Service'
            RefreshMode = 'Push'
            DependsOn = '[PartialConfiguration]TestService'
        }
    }
}

PartialConfigInPush -NodeName PSConfEu-VM2 -PullServerUrl 'http://psconfeu-dc:8080/PSDSCPullServer.svc' -RegistrationKey '6d271d28-dd50-4b16-86d3-b917d2d7b1af' -OutputPath C:\Demos\PartialConfigInPush -Verbose
Set-DscLocalConfigurationManager -Path C:\Demos\PartialConfigInPush -Verbose

#Publish first fragment
Publish-DscConfiguration -Path C:\Demos\PCandCNS\Configurations\TestDependentService -ComputerName PSConfEU-VM2 -Verbose

#Start enact; This should result in an error
Start-DscConfiguration -UseExisting -ComputerName PSConfEU-VM2 -Wait -Verbose

#Publish second fragment
Publish-DscConfiguration -Path C:\Demos\PCandCNS\Configurations\TestService -ComputerName PSConfEU-VM2 -Verbose

#Start enact; This should work
Start-DscConfiguration -UseExisting -ComputerName PSConfEU-VM2 -Wait -Verbose