﻿#Cryptographic Message Sysntax (req. PowerShell 5)
#Remove private key if present
get-item -Path Cert:\CurrentUser\My\5BE5249D15D5CF98BBEC0FDA21CBF7225E12470F | Remove-Item

$Mytesttext = 'PowerShell Conference Europe really rocks!'

#Encrypt text with public key
$MyEncryptedText = (Protect-CmsMessage -To C:\Temp\PSConfEU\CMS\cl-srv01-ps-cms.cer -Content $Mytesttext)


$MyEncryptedText


Unprotect-CmsMessage -Content $MyEncryptedText

#import private key in personal certificate store

$cert = ( Get-ChildItem -Path C:\Temp\PSConfEU\CMS\cl-srv01-ps-cms-withPK.pfx)

$CertPW = ConvertTo-SecureString 'MSbell!' -AsPlainText -Force 

$cert | Import-PfxCertificate -Password $CertPW -CertStoreLocation Cert:\CurrentUser\My

#open mmc to prove
& C:\Temp\PSConfEU\cms\certconsole.msc
#try again

Unprotect-CmsMessage -Content $MyEncryptedText