﻿#remove private key from store
get-item -Path Cert:\CurrentUser\My\5BE5249D15D5CF98BBEC0FDA21CBF7225E12470F | Remove-Item

#This is only to encrypt the MasterKey of PSConfEu.kdbx

$MasterKey = 'TestMasterKey!'
Protect-CmsMessage -To 'C:\TEMP\PSConfEU\CMS\cl-srv01-ps-cms.cer' -Content $MasterKey -OutFile 'C:\Temp\PSConfEU\CMS\encrpytedMasterKey.txt'


notepad.exe C:\Temp\PSConfEU\CMS\encrpytedMasterKey.txt



