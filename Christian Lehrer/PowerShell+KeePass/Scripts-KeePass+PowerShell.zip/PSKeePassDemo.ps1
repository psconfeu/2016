﻿Import-Module PSKeePass -Force

#The KeePass Database has to be created manually
#Open KeePass.exe

&'C:\Program Files (x86)\KeePass Password Safe 2\KeePass.exe'


#Path for new KeePass Database: C:\Temp\PSConfEU\KeePass\PSConfEU.kdbx

#MasterKey for Demo-DB: TestMasterKey! 
#Create sample-entry in Windows group: Title: PSConfEU
#(Don´t forget to save DB in GUI!)

#Set the standardconfiguration for KeePass

Set-KeePassConfiguration -KPDBDefaultpath 'C:\TEMP\PSConfEU\KeePass\PSConfEU.kdbx' -KPProgramFolder 'C:\Program Files (x86)\KeePass Password Safe 2'

Get-KeePassConfiguration


#Prepare PSCredental object to open KeePass database. The username does not matter but must not be empty.

$mycred = Get-Credential
#Get a test-entry

Get-KeePassEntry -DBcredential $mycred -TopLevelGroupName Windows -Title PSConfEU


#get the same entry as PSCredential object

Get-KeePassEntry -DBcredential $mycred -TopLevelGroupName Windows -Title PSConfEU -AsSecureStringCredential


#create a new entry
#1. Prepare credentials

$newEntryCreds = Get-Credential

#2. Create new entry
New-KeePassEntry -DBcredential $mycred -TopLevelGroupName Windows -Title 'NewPSConfEUEntry' -EntryCredential $newEntryCreds

Get-KeePassEntry -DBcredential $mycred -TopLevelGroupName Windows -Title 'NewPSConfEuEntry'




#Update Entry

Set-KeePassEntry -DBcredential $mycred -TopLevelGroupName Windows -Title 'NewPSConfEUEntry' -EntryCredential $newEntryCreds -url 'www.psconf.eu' -Notes 'PowerShell Conference Europe rocks!'