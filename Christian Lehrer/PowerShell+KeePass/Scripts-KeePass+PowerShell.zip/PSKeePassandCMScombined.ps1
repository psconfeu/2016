﻿#Delete private key
get-item -Path Cert:\CurrentUser\My\5BE5249D15D5CF98BBEC0FDA21CBF7225E12470F | Remove-Item

$Password = (Unprotect-CmsMessage -Content ([string](get-content C:\temp\PSConfEU\CMS\encrpytedMasterKey.txt))) | ConvertTo-SecureString -AsPlainText -Force
$Username = 'dummyusername'


$KeePassCred = New-Object System.Management.Automation.PSCredential($Username,$Password)

Get-KeePassEntry -DBcredential $KeePassCred -TopLevelGroupName Windows -Title PSConfEu


#Add private key

$cert = ( Get-ChildItem -Path C:\Temp\PSConfEU\CMS\cl-srv01-ps-cms-withPK.pfx)

$CertPW = ConvertTo-SecureString 'MSbell!' -AsPlainText -Force 

$cert | Import-PfxCertificate -Password $CertPW -CertStoreLocation Cert:\CurrentUser\My

#Try again


Get-KeePassEntry -DBcredential $KeePassCred -TopLevelGroupName Windows -Title PSConfEu