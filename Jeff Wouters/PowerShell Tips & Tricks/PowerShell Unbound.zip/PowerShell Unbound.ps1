﻿#region Prep
$Files = Get-ChildItem d:\ -Recurse
#endregion Prep

#region Hex
0xfd
#endregion Hex

#region Location, location, location
Push-Location 'D:\Methos'
Push-Location 'C:\Windows\system32\WindowsPowerShell\v1.0\Modules'
Pop-Location
Pop-Location

$MyInvocation.MyCommand.Path
Push-Location 'C:\Users\Methos\Desktop\Events\PSConf EU\PowerShell Tips & Tricks\'
.\test.ps1
Pop-Location
#endregion Location, location, location

#region Prompt
function Prompt { 
    "JeffWouters.nl > "
}
#endregion Prompt

#region Splatting
$Hash = @{
    'FilePath'               = 'C:\windows\system32\ipconfig.exe'
    'ArgumentList'           = '/All'
    'RedirectStandardOutput' = 'D:\test\ipconfig.txt'
}
#Start-Process -FilePath -ArgumentList -RedirectStandardOutput
Start-Process @Hash
#endregion Splatting

#region Where
$Files | Where-Object {$_.Name -like "*PowerShell*"}
$Files | Where-Object {$PSItem.Name -like "*PowerShell*"}
$Files | Where-Object Name -like "*PowerShell*"
$Files.Where({$_.Name -like "*PowerShell*"})

measure-command {$Files | Where-Object {$_.Name -like "*PowerShell*"}} | Select-Object -ExpandProperty totalmilliseconds
measure-command {$Files | Where-Object {$PSItem.Name -like "*PowerShell*"}} | Select-Object -ExpandProperty totalmilliseconds
measure-command {$Files | Where-Object Name -like "*PowerShell*"} | Select-Object -ExpandProperty totalmilliseconds
measure-command {$Files.Where($Name -like "*PowerShell*")} | Select-Object -ExpandProperty totalmilliseconds
#endregion Where

#region PSDrives
Get-PSDrive
Push-Location HKLM:\SOFTWARE
Get-ChildItem
Pop-Location
#endregion PSDrives

#region String formatting
$Name = 'Jeff'
$Event = 'MMS'

'Hello, my name is $Name'
"Hello, my name is $Name"

'Hello, my name is {0}' -f $Name
'Hello, my name is {0} and I am at $Event' -f $Name
"Hello, my name is {0} and I am at $Event" -f $Name

'Hello, my name is {1} and it is {0:HH}:{0:mm} on {0:dd}-{0:MM}-{0:yyyy}' -f (Get-Date),$Name
#endregion String formatting

#region Formatting output
Get-Process | Group-Object -Property Name | Sort-Object -Descending | Format-Table
Get-Process | Group-Object -Property Name | Format-Table | Sort-Object -Descending
#endregion Formatting output

#region Variable squeezing
$Procs = Get-Process
($Procs = Get-Process)
#endregion Variable squeezing

#region Passthru
set-alias 'foo' 'Get-Process'
foo
set-alias 'foo' 'Get-Process' -PassThru
Get-Command -ParameterName passthru | Measure-Object
Get-Command -ParameterName passthru
#endregion Passthru

#region Type casting
[int]$Int = 8
[string]$String = 'PSConf'

$Int = 'PSConf'
$Int.GetTypeCode()
$String = 'one','two'
$String
$string.GetTypeCode()

Remove-Variable Int,String

$Int = [int]8
$String = [string]'PSConf'

$Int = 'PSConf'
$Int
$Int.GetTypeCode()
$String = 'one','two'
$String
$string.GetType()
#endregion Type casting

#region Music
[console]::beep(440,500) 
[console]::beep(440,500) 
[console]::beep(440,500) 
[console]::beep(349,350) 
[console]::beep(523,150) 
[console]::beep(440,500) 
[console]::beep(349,350) 
[console]::beep(523,150) 
[console]::beep(440,1000) 
[console]::beep(659,500) 
[console]::beep(659,500) 
[console]::beep(659,500) 
[console]::beep(698,350) 
[console]::beep(523,150) 
[console]::beep(415,500) 
[console]::beep(349,350) 
[console]::beep(523,150) 
[console]::beep(440,1000)
#endregion Music

#region Don't name your variable Error
Get-Variable Error
Get-Variable
#endregion Don't name your variable Error

#region Red is scarry
Get-Process -ComputerName fake
(Get-Host).PrivateData
(Get-Host).PrivateData.ErrorForegroundColor = 'Green'
Get-Process -ComputerName fake
#endregion Red is scarry

#region Open Explorer in current path
Push-Location 'C:\windows\system32\WindowsPowerShell\v1.0\Modules\Hyper-V\2.0.0.0'
Get-Location
start .
Invoke-Item .
ii .
#endregion Open Explorer in current path

#region Clipboard
get-process *power* | clip
get-command -Noun Clipboard
#endregion Clipboard

#region Dot sourcing
ise 'C:\Users\Methos\Desktop\Events\PSConf EU\PowerShell Tips & Tricks\Functions.ps1'
one
. 'C:\Users\Methos\Desktop\Events\PSConf EU\PowerShell Tips & Tricks\Functions.ps1'
one
#endregion Dot sourcing

#region Crtl-C & Crtl-V
Start-Process powershell
Start-Process cmd
#endregion Ctrl-C & Ctrl-V

#region Know what you execute!
#Great on WinSrv12 SQL Servers!
icm {gps *sv* | ? vm -gt 50 | % {spps $_ -f -WhatIf}}
#region Explained
invoke-command -ScriptBlock { 
    Get-Process -Name *sv* | Where-Object {$_.vm -gt 50} | foreach { 
        Stop-Process $_ -Force } }
#endregion Explained
#Found online
iex (New-Object Net.WebClient).DownloadString("http://bit.ly/e0Mw9w")
#endregion Know what you execute!