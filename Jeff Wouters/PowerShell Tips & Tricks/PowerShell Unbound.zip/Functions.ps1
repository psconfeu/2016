﻿function One {
    'This is function One'
}

function Two {
    'This is function Two'
}

function Three {
    'This is function Three'
}