﻿# practical examples
break

$logFile = 'C:\Demo\RegEx\dism.log'

# TIP! Don't use Get-Content | Select-String, use Select-String -Path

# show all lines with the word 'Error'
Select-String -Path $logFile -Pattern 'Error'

# show all lines with either the word 'Error' or 'Warning'
Select-String -Path $logFile -Pattern 'Error|Warning'

# show all lines with a path
$pattern = '.:\\.+\\.+\..{1,3}'
Select-String -Path $logFile -Pattern $pattern

# multiple capture groups
$string = 'Date: 01.05.1980 - ID: 0233 - WARNING - Message: Are you not using PowerShell yet? - Status: OK'
$pattern = 'Date: (.+) . ID: (.+) . (.+) . Message: (.+) . Status: (.+)'
$res = $string | Select-String -Pattern $pattern
foreach ($group in $res.Matches.Groups) {
    $group.Value
}

# -replace
'String with numbers 12345' -replace('\d','')

# .NET
$pattern = 'PowerShell'
$string = 'This is PowerShell'
$regex = New-Object -TypeName System.Text.RegularExpressions.Regex -ArgumentList $pattern

# IsMatch - boolean
$regex.IsMatch($string)

# match one
$regex.Match($string)

# multiple matches
$regex.Matches($string)

# Regex Type Accelerator
[Regex]::IsMatch($string,$pattern)
[Regex]::Match($string,$pattern)









# validate email address (local@domain) from wikipedia
<#
Valid email addresses

prettyandsimple@example.com
very.common@example.com
disposable.style.email.with+symbol@example.com
other.email-with-dash@example.com
x@example.com (one-letter local part)
"much.more unusual"@example.com
"very.unusual.@.unusual.com"@example.com
"very.(),:;<>[]\".VERY.\"very@\\ \"very\".unusual"@strange.example.com
admin@mailserver1 (local domain name with no TLD)
#!$%&'*+-/=?^_`{}|~@example.org
"()<>[]:,;@\\\"!#$%&'*+-/=?^_`{}| ~.a"@example.org
" "@example.org (space between the quotes)
example@localhost (sent from localhost)
example@s.solutions (see the List of Internet top-level domains)
user@com
user@localserver
user@[IPv6:2001:db8::1]

Invalid email addresses

Abc.example.com (no @ character)
A@b@c@example.com (only one @ is allowed outside quotation marks)
a"b(c)d,e:f;g<h>i[j\k]l@example.com (none of the special characters in this local part are allowed outside quotation marks)
just"not"right@example.com (quoted strings must be dot separated or the only element making up the local-part)
this is"not\allowed@example.com (spaces, quotes, and backslashes may only exist when within quoted strings and preceded by a backslash)
this\ still\"not\\allowed@example.com (even if escaped (preceded by a backslash), spaces, quotes, and backslashes must still be contained by quotes)
john..doe@example.com (double dot before @)
with caveat: Gmail lets this through, Email address#Local-part the dots altogether
john.doe@example..com (double dot after @)

#>