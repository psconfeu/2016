﻿# regex - bonus
break

# validate IP address
#https://msdn.microsoft.com/en-us/library/system.net.ipaddress(v=vs.110).aspx

$ips = @(
    '127.0.0.1',
    '299.54.999.1',
    '10.0.0.1',
    '67.40',
    '2001:0:9d38:6abd:107d:3794:aa03:937a'
)

foreach ($ip in $ips) {
    if ($ip -as [IPAddress]) {
        Write-Host "$ip is a valid IP address" -ForegroundColor Green
    }
    else {
        Write-Host "$ip is not a valid IP address" -ForegroundColor Red
    }
}

# validate email address
# https://msdn.microsoft.com/en-us/library/system.net.mail.mailaddress.aspx

$emails = @(
    'prettyandsimple@example.com',
    'x@example.com',
    'disposable.style.email.with+symbol@example.com',
    'Abc.example.com',
    'A@b@c@example.com',
    'john..doe@example.com',
    'john.doe@example..com',
    'this is"not\allowed@example.com'
)

foreach ($email in $emails) {
    if ($email -as [MailAddress]) {
        Write-Host "$email is a valid email address" -ForegroundColor Green
    }
    else {
        Write-Host "$email is not a valid email address" -ForegroundColor Red
    }
}