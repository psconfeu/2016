﻿#regex
break

## Simple string matching

# Does it match
'PowerShell rocks!' -match 'PowerShell'

# Find match
'PowerShell rocks!' | Select-String -Pattern 'PowerShell'

## Character escapes
# \ is the escape character, except when it's used with a special character
# the most used are
# \r - carriage return
# \v - vertical tab
# \n - new line

$text = @'
This is a test
Next line
'@

$textSplit = $text -Split("\r")
$textSplit[0]

#GOTCHA!!
$textSplit2 = $text.Split("\r")
$textSplit2[0]

## Character class

# show in RegexBuddy

#> character group

#> Character range (RegexBuddy)

# [A-Z]
# [A-Za-z]
# [0-9]

#> Other
# .  - wildcard
# \w - any word character
# \W - any non-word character
# \s - any white-space character
# \S - any non-white-space character
# \d - any decimal digits
# \d - any digits other than decimal digits

## Anchors

<#
    ^  - start at the beginning of the string or line
    $  - end of the string or before \n at the end of the string or line
    \A - start of the string
    \Z - end of the string or before \n at the end of the string
    \z - end of the string
#>

'I love PowerShell' -match 'PowerShell'
'I love PowerShell' -match '^PowerShell'
'I love PowerShell' -match 'PowerShell$'

# \b - word boundaries

'PowerShell' -cmatch 'power'
'PowerShell' -match 'shell'
'PowerShell' -match '\bshell'
'PowerShell' -match '\bPower'
'PowerShell' -match 'Power\b'

## Quantifiers

# \d{0,3}.\d{0,3}.\d{0,3}.\d{0,3} (127.0.0.1)
# PowerShell.+ (PowerShell is king!)

<#
    * - zero or more times
    + - one or more times
    ? - zero or one time
    {n} - exactly n times
    {n,m} - between n and m times

    add ? to use lazy matching
#>

# Lazy vs greedy matching example: html tags
# regex: <.+?> vs <.+>
# string: <a href="link"><b>This is a link</b></a>

## Grouping

# In RegexBuddy, show subexpression and non-capturing groups
# ex: (.+) is king

## Alternation

# | (any one element)
# ex: (?:PowerShell|Python) is king

## lookahead / lookbehind

# positive lookbehind (?<=)
# regex: (?<=Message: )(.+)
#        (?<=ID: )(\d+)
# Date: 01.05.1980 - ID: 0286 - INFO - Message: PowerShell rocks! - Status: 234
# Date: 01.05.1980 - ID: 0233 - WARNING - Message: Are you not using PowerShell yet? - Status: OK

# negative lookbehind (?<!)
# regex: (?<!INFO)(?: - Message: )(.+)(?: - )

# positive lookahead
# regex: (?:Message: )(.+)(?: - )(?=Status: OK)

# negative lookahead
# regex: (?:Message: )(.+)(?: - )(?!Status: OK)