﻿# Using PowerForensics module - RUN AS ADMINISTRATOR
break

# get all the files from the Master File Table
Measure-Command {
    $allFiles = Get-ForensicFileRecord -VolumeName c:
} | Select-Object -ExpandProperty TotalSeconds
$allFiles.Count

# get our text files by doing a filter on the collection in memory
Measure-Command {
    $txtFiles = $allFiles | Where-Object {-not $_.Directory -and $_.Name -like '*.txt'}
} | Select-Object -ExpandProperty TotalSeconds
$txtFiles.Count

# let's use where instead of where-object
Measure-Command {
    $txtFiles = $allFiles.Where{-not $_.Directory -and $_.Name -like '*.txt'}
} | Select-Object -ExpandProperty TotalSeconds


