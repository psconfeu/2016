﻿# .NET
break # demo, use F8 to run each line/selection

## 01 - EnumerateFiles, with AllDirectories option
[System.IO.Directory]::EnumerateFiles($rootPath,'*.txt',[System.IO.SearchOption]::AllDirectories)

# This is a problem, access denied errors are terminating errors, with no possibility(?) of easy handling

## 02 - Solution - Roll our own recursive wrapper function
function Invoke-DotNetSearch {
    param([string]$Path)

    $directories = [System.IO.Directory]::EnumerateDirectories($Path)
    $files = [System.IO.Directory]::EnumerateFiles($Path,'*.txt')

    foreach ($directory in $directories) {
        try {
            Invoke-DotNetSearch $directory
        }
        catch {
            #Write-Warning "Error accessing $directory [$($_.Exception.Message)]"
        }

    }

    Write-Output $files
}

Measure-Command {$allFiles = Invoke-DotNetSearch 'c:\'}| Select-Object -ExpandProperty TotalSeconds

## 02b - Let's also try using the GetDir/GetFile methods, just in case
function Invoke-DotNetSearch2 {
    param([string]$Path)

    $directories = [System.IO.Directory]::GetDirectories($Path)
    $files = [System.IO.Directory]::GetFiles($Path,'*.txt')

    foreach ($directory in $directories) {
        try {
            Invoke-DotNetSearch $directory
        }
        catch {
            #Write-Warning "Error accessing $directory [$($_.Exception.Message)]"
        }

    }

    Write-Output $files
}

Measure-Command {$allFiles = Invoke-DotNetSearch 'c:\'}| Select-Object -ExpandProperty TotalSeconds

# By rolling our own wrapper function around the .NET methods, to be able to properly handle errors
# we are essentially "undoing" any speed benefits from using them. At least in this particular example.