﻿# PowerShell
break # demo, use F8 to run each line/selection

$rootPath = 'c:\' # about 400k files
$originalPath = Get-Location

Set-Location -Path $rootPath

## 01 - Typical use
$files = ls *.txt -r    # Throws error messages for folders without proper access

## 02 - In PowerShell it's easy to ignore errors
Measure-Command {$files = Get-ChildItem *.txt -Recurse -ErrorAction SilentlyContinue}
$files.Count

## 03 - Let's use the -Filter parameter
Measure-Command {$files = Get-ChildItem -Path . -Filter *.txt -Recurse -ErrorAction SilentlyContinue} | Select-Object -ExpandProperty TotalSeconds

## 04 - Let's try to use the -File parameter from the File System provider to see if further optimization is possible
Measure-Command {$files = Get-ChildItem -Path . -Filter *.txt -Recurse -File -ErrorAction SilentlyContinue} | Select-Object -ExpandProperty TotalSeconds
# perhaps surprisingly, this doesn't help at all, at least not in regards to speed, it will help to filter out folders from the result though

### This is probably as far as we can get using PowerShell alone. It's not bad, but for the fun of it, let's compare to using good old DOS

## 05 - Using dir command from DOS (drawback of course, no objects)
Measure-Command {$files = & cmd.exe /c dir *.txt /s /b}| Select-Object -ExpandProperty TotalSeconds   # this is probably what we should aim for with regards to speed