﻿$file = 'C:\Demo\ChasingTheSeconds\1m.csv'

Measure-Command {$res = Get-Content -Path $file | Select-Object -Last 10}

Measure-Command {$res = Get-Content -Path $file -Tail 10}

$file = 'C:\Demo\ChasingTheSeconds\myFiles.csv'
Measure-Command {$res = Get-Content -Path $file -Tail 10}