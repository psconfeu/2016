﻿Import-Module 'c:\users\ojk\documents\github\communary.fileextensions\communary.fileextensions.psd1' -Force

Measure-Command {
    $files = Invoke-FastFind -Path 'c:\' -Filter '*.txt' -File -Recurse
} | Select-Object -ExpandProperty TotalSeconds

$files.count