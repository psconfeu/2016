﻿Measure-Command {0..1000000 | Get-Random}
Measure-Command {Get-Random -Minimum 0 -Maximum 1000000}