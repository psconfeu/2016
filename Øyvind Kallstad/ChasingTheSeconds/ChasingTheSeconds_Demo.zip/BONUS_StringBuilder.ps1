﻿$n = 100000

$string = ''

Measure-Command {
for ($i = 0; $i -lt $n; $i++) {
    [string]$string += [string]$i
}
}

#$string

$sb = New-Object -TypeName System.Text.StringBuilder

Measure-Command {
for ($i = 0; $i -lt $n; $i++) {
    [void]$sb.Append([string]$i)    
}
}

#$sb.ToString()